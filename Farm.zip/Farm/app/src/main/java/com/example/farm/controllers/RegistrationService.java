package com.example.farm.controllers;
import com.example.farm.model.RegistrationRequest;

import retrofit2.Call;
import retrofit2.http.Body;
import retrofit2.http.POST;

public interface RegistrationService {
    @POST("registration") // Replace with your actual endpoint
    Call<YourResponseClass> registerUser(@Body RegistrationRequest request);


}
