package com.example.farm;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

public class activitypage extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_activitypage);
    }
}