package com.example.farm;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.text.InputType;
import android.view.MotionEvent;
import android.view.View;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.Toast;

import com.example.farm.controllers.RegistrationService;
import com.example.farm.controllers.YourResponseClass;
import com.example.farm.model.RegistrationRequest;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;
import retrofit2.Retrofit;
import retrofit2.converter.gson.GsonConverterFactory;

public class Registration_page extends AppCompatActivity {

    EditText name,email,phone,password;
    LinearLayout signupbtn;

    String namet,emailt,phonet,passwordt;

    private EditText passwordEditText;

    private SharedPreferencesManager prefsManager;



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.registration_page);

        name=findViewById(R.id.name);
        email= findViewById(R.id.email);
        phone= findViewById(R.id.phoneno);
        password = findViewById(R.id.password);
        signupbtn=findViewById(R.id.signupbtn);



        prefsManager = new SharedPreferencesManager(this);






        password.setOnTouchListener(new View.OnTouchListener() {
            @Override
            public boolean onTouch(View view, MotionEvent event) {
                if (event.getAction() == MotionEvent.ACTION_UP) {
                    int drawableRight = 2; // Index of the drawableEnd (2 for right-most drawable)
                    if (event.getRawX() >= (view.getRight() - password.getCompoundDrawables()[drawableRight].getBounds().width())) {
                        // Toggle input type between text and textPassword
                        if (password.getInputType() == (InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_VARIATION_PASSWORD)) {
                            password.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_VARIATION_VISIBLE_PASSWORD);
                        } else {
                            password.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_VARIATION_PASSWORD);
                        }
                        password.setSelection(password.getText().length()); // Keep cursor at the end

                        // Refresh the appearance of the EditText
                        password.refreshDrawableState();

                        return true;
                    }
                }
                return false;
            }
        });


        signupbtn.setOnClickListener(new View.OnClickListener() {


            @Override
            public void onClick(View view) {

                namet=name.getText().toString();
                emailt=email.getText().toString();
                phonet=phone.getText().toString();
                passwordt=password.getText().toString();



                Retrofit retrofit = new Retrofit.Builder()
                        .baseUrl("https://dev.cofastudio.com/my_farm/myfarm.php/registration/") // Replace with your API base URL
                        .addConverterFactory(GsonConverterFactory.create())
                        .build();

                RegistrationService registrationService = retrofit.create(RegistrationService.class);



                RegistrationRequest registrationRequest = new RegistrationRequest(
                        namet,emailt,phonet,passwordt
                );

                Call<YourResponseClass> call = registrationService.registerUser(registrationRequest);

                call.enqueue(new Callback<YourResponseClass>() {
                    @Override
                    public void onResponse(Call<YourResponseClass> call, Response<YourResponseClass> response) {
                        if (response.isSuccessful()) {
                            // Registration successful, handle the response here
                            YourResponseClass responseBody = response.body();
                            // Display a success message
                            Toast.makeText(getApplicationContext(), "Registration successfully", Toast.LENGTH_SHORT).show();

                            Intent signup=new Intent(Registration_page.this,Login_page.class);
                            startActivity(signup);

                            if (responseBody != null) {
                                String dataString = responseBody.toString();
                                Toast.makeText(getApplicationContext(), "Posted Data: " + dataString, Toast.LENGTH_LONG).show();
                            }

                        } else {
                            // Registration failed, handle the error here
                            // You can access the error message with response.errorBody().string()
                            Toast.makeText(getApplicationContext(), "Data posting fail", Toast.LENGTH_SHORT).show();

                        }
                    }

                    @Override
                    public void onFailure(Call<YourResponseClass> call, Throwable t) {
                        Toast.makeText(getApplicationContext(), "Internal Server error", Toast.LENGTH_SHORT).show();

                    }
                });


            }
        });



    }
}