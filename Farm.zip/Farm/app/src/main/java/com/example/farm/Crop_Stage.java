package com.example.farm;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

public class Crop_Stage extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_crop_stage);
    }
}