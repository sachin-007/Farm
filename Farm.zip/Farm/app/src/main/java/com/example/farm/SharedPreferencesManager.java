package com.example.farm;


import android.content.Context;
import android.content.SharedPreferences;

public class SharedPreferencesManager {
    private static final String PREF_NAME = "MyPrefs";
    private static final String USER_ID_KEY = "user_id";
    private static final String USER_ID = "";

    private SharedPreferences preferences;


    public SharedPreferencesManager(Context context) {
        preferences = context.getSharedPreferences(PREF_NAME, Context.MODE_PRIVATE);
    }

    public void saveUserId(String userId) {
        preferences.edit().putString(USER_ID_KEY, userId).apply();
    }

    public String getUserId() {
        return preferences.getString(USER_ID_KEY, null);
    }

    public void remove() {
        SharedPreferences.Editor editor = preferences.edit();
        editor.putString(USER_ID, null);
        editor.apply();
    }
}
