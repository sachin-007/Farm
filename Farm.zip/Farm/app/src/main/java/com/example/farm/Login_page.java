package com.example.farm;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.LinearLayout;
import android.widget.TextView;

public class Login_page extends AppCompatActivity {

    TextView forget;
    LinearLayout welcomeBack;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.login_page);
         forget =  findViewById(R.id.forget);

        forget.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent forget = new Intent(Login_page.this, forget_password.class);
                startActivity(forget);
            }
        });

        welcomeBack = findViewById(R.id.welcomeBack);

        welcomeBack.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent welcomeBack = new Intent(Login_page.this, MainActivity.class);
                startActivity(welcomeBack);
            }
        });
    }
}