package com.example.farm.controllers;

public class YourResponseClass {
    private String message;
    private int userId; // If the server sends back the user ID
    // Other fields as per your API response
}
